#if !defined(AFX_STDAFX_H__B15E9292_E959_4710_BBA3_FB04562B04F1__INCLUDED_)
#define AFX_STDAFX_H__B15E9292_E959_4710_BBA3_FB04562B04F1__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif 

#define VC_EXTRALEAN		

#include <afxwin.h>        
#include <afxext.h>        
#include <afxdisp.h>        
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>		
#endif 


//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_STDAFX_H__B15E9292_E959_4710_BBA3_FB04562B04F1__INCLUDED_)
